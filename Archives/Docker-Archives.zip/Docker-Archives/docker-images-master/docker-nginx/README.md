![Alt text](http://fusengine.ch/img/nginx.svg)
=============================================

### Directory and port

```
  - VOLUME :
      - /var/www/html
      - /etc/nginx/sites-enabled/

- EXPOSE : 80
```
# Nginx php7
This is a Container nginx with php7.0-fpm
