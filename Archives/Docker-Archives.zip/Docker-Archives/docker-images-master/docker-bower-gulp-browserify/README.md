![Alt text](http://fusengine.ch/img/bower.svg)
==============================================

### bower install packages

```
VOLUMES : /data
```

### default packges

```
npm, nodejs, grunt & node
```

&copy; 2015 [Fusengine](http://fusengine.com)
