#!/bin/bash

# add script function
source /root/script_base.sh

# Update Ubuntu
update

# Install_packages
install_packages

# Upgrade ubuntu
upgrade

# Clean ubuntu
clean_ubuntu
