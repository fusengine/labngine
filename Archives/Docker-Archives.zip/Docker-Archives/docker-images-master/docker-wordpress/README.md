![Alt text](http://fusengine.ch/img/wordpress.svg)
=============================================

### Directory and port

```
  - VOLUME : /etc/nginx/sites-enabled/
  - WORKDIR: /wordpress

- EXPOSE : 80
```
# Nginx php7
This is a Container nginx with php7.0-fpm
