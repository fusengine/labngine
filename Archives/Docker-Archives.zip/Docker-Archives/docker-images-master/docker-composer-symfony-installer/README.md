![Alt text](http://www.fusengine.ch/img/laravel-composer.svg)
=============================================================

```

Use symfony => symfony new blog
Use composer => composer.

```

### Composer

```
to composer use personnal with GITHUB_TOKEN
GITHUB_TOKEN 89uew9sjfosnamf90fhasipfi this is a exemple

VOLUME : /root/.composer
add your config on /root/.composer
exemple auth.json
```

### Laravel use

```
for exemple: composer create-project --prefer-dist laravel/laravel myproject
```

```
VOLUME :  /var/www/html
```

&copy; 2015 [Fusengine](http://fusengine.com)
