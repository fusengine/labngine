![Alt text](http://fusengine.ch/img/centos.svg)
===============================================

< This is centos latest to update and upgrade >

### Install default packages

```
vim, wget, curl, git, vim, openssh-server
```

&copy; 2015 [Fusengine](http://fusengine.com)
