![Alt text](http://www.fusengine.ch/img/node.svg)
=================================================

This is Ubuntu-upstart to update and upgrade

### default packages

```
this image have nodejs, npm and grunt
```

&copy; 2015 [Fusengine](http://fusengine.com)
