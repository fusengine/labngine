sudotouch .bowerrc
echo '{ "allow_root": true }' > /.bowerrc
