![Alt text](http://www.fusengine.ch/img/laravel-composer.svg)
=============================================================

```
Use laravel => laravel new blog
Use symfony => laravel new blog
Use composer => composer.

```

```
VOLUME :  /var/www/html
```

&copy; 2015 [Fusengine](http://fusengine.com)
